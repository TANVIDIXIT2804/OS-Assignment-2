# Pintos
Labs for the CS 301. 

[Pintos](http://pintos-os.org) is a teaching operating system. The main source code, documentation and assignments are developed by Ben Pfaff and others from Stanford (refer to its [LICENSE](./LICENSE)). This version borrows the changes performed by Ryan Huang.
